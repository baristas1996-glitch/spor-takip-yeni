# Spor Takip

Cloudflare Workers Static Assets üzerinde yayınlanabilen, kurulum gerektirmeyen bir PWA.

## Özellikler
- Antrenman adı ve tarihiyle antrenman kaydı
- Hareket kütüphanesi ve açılır listeden hareket seçimi
- Hareket başına set, tekrar ve ağırlık kaydı
- Hareket bazında zaman içindeki ağırlık gelişimi grafiği
- Veriler bu cihazın tarayıcısında saklanır (localStorage)
- JSON yedek dışa/içe aktarma
- Ana ekrana eklenebilir ve temel çevrimdışı desteği vardır

## Cloudflare
Bu depo, mevcut Worker adı `fancy-disk-f4d2` ile eşleşecek şekilde ayarlanmıştır. Cloudflare Workers > ilgili Worker > Settings > Builds bölümünden GitHub deposunu bağlayın. Build command boş; deploy command `npx wrangler deploy` olmalıdır.

> Not: İlk sürüm verileri cihazda saklar. iPhone'daki Safari verileri ile başka cihazlardaki veriler otomatik eşitlenmez. Bulut senkronizasyonu sonraki aşamada ayrıca eklenebilir.
